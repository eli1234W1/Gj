@extends('templates/wrapper', [
    'css' => ['body' => 'bg-neutral-900']
])

@section('container')
    <div id="app"></div>

    <script>
        // As soon as you adjust or remove this data, and we see this, will result in a lawsuit or multiple sanctions.
        localStorage.setItem("username", "PepijnWeijers");
        localStorage.setItem("BuyerID", "305532");
        localStorage.setItem("Timestamp", "1697181788");
    </script>
@endsection
